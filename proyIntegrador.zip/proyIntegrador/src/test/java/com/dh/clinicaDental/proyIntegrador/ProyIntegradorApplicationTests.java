package com.dh.clinicaDental.proyIntegrador;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyIntegradorApplicationTests {

	@Test
	void contextLoads() {
	}

}
