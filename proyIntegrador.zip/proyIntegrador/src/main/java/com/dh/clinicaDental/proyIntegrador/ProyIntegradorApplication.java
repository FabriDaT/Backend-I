package com.dh.clinicaDental.proyIntegrador;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyIntegradorApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyIntegradorApplication.class, args);
	}

}
