package com.FabriGroup.ApiClase25;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiClase25ApplicationTests {

	@Test
	void contextLoads() {
	}

}
