package com.FabriGroup.ApiClase25;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiClase25Application {

	public static void main(String[] args) {
		SpringApplication.run(ApiClase25Application.class, args);
	}

}
