package com.DH.PatronMVCClase22;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PatronMvcClase22ApplicationTests {

	@Test
	void contextLoads() {
	}

}
